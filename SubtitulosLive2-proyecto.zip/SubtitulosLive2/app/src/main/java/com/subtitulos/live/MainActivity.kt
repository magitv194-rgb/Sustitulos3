package com.subtitulos.live

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var languageSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        languageSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Automático (japonés o inglés)", "Japonés", "Inglés")
            )
        }

        val title = TextView(this).apply {
            text = "SUBTÍTULOS LIVE 2"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Traduce japonés e inglés al español mientras ves contenido compatible."
            textSize = 16f
            gravity = Gravity.CENTER
        }
        val label = TextView(this).apply {
            text = "Idioma de la voz:"
            textSize = 16f
        }
        val start = Button(this).apply {
            text = "Iniciar subtítulos"
            setOnClickListener { beginSetup() }
        }
        val stop = Button(this).apply {
            text = "Detener subtítulos"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                Toast.makeText(this@MainActivity, "Servicio detenido", Toast.LENGTH_SHORT).show()
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
            addView(title)
            addView(description)
            addView(label)
            addView(languageSpinner)
            addView(start)
            addView(stop)
        })
    }

    private fun beginSetup() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            Toast.makeText(this, "Activa 'Mostrar sobre otras aplicaciones' y vuelve a abrir la app.", Toast.LENGTH_LONG).show()
            return
        }

        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)

        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
            return
        }
        requestScreenCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS &&
            grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) {
            requestScreenCapture()
        } else {
            Toast.makeText(this, "Necesitas conceder los permisos para continuar.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Usado para compatibilidad con el flujo de MediaProjection")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val mode = when (languageSpinner.selectedItemPosition) {
                1 -> "ja"
                2 -> "en"
                else -> "auto"
            }
            val serviceIntent = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                .putExtra(CaptureService.EXTRA_LANGUAGE_MODE, mode)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            moveTaskToBack(true)
        }
    }

    companion object {
        private const val REQUEST_PERMISSIONS = 10
        private const val REQUEST_CAPTURE = 11
    }
}
