package com.subtitulos.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

class CaptureService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var audioRecord: AudioRecord? = null
    private var projection: MediaProjection? = null
    private var overlay: TextView? = null
    private var englishModel: Model? = null
    private var japaneseModel: Model? = null
    private var englishRecognizer: Recognizer? = null
    private var japaneseRecognizer: Recognizer? = null
    private var englishTranslator: Translator? = null
    private var japaneseTranslator: Translator? = null
    private val languageIdentifier by lazy { LanguageIdentification.getClient() }
    private var languageMode = "auto"
    @Volatile private var lastText = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        languageMode = intent.getStringExtra(EXTRA_LANGUAGE_MODE) ?: "auto"
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Subtítulos Live activos")
            .setContentText("Preparando reconocimiento de voz…")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        try {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            @Suppress("DEPRECATION")
            val resultData = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                intent.getParcelableExtra(EXTRA_RESULT_DATA)
            } ?: throw IllegalStateException("Falta la autorización para capturar audio.")

            projection = getSystemService(MediaProjectionManager::class.java)
                .getMediaProjection(resultCode, resultData)

            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, mainHandler)

            showOverlay()
            running = true
            prepareModelsAndStartAudio()
        } catch (e: Exception) {
            showMessage("No se pudo iniciar: ${e.message ?: "error desconocido"}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun prepareModelsAndStartAudio() {
        thread(name = "prepare-vosk-models") {
            try {
                showMessage("Descargando modelos de voz. La primera vez puede tardar…")
                val enDir = downloadAndExtractModel(
                    "vosk-model-small-en-us-0.15",
                    "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
                )
                val jaDir = downloadAndExtractModel(
                    "vosk-model-small-ja-0.22",
                    "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip"
                )

                englishModel = Model(enDir.absolutePath)
                japaneseModel = Model(jaDir.absolutePath)
                englishRecognizer = Recognizer(englishModel, SAMPLE_RATE.toFloat())
                japaneseRecognizer = Recognizer(japaneseModel, SAMPLE_RATE.toFloat())

                prepareTranslators()
            } catch (e: Exception) {
                showMessage("Error preparando modelos: ${e.message}")
            }
        }
    }

    private fun prepareTranslators() {
        val conditions = DownloadConditions.Builder().build()
        englishTranslator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build()
        )
        japaneseTranslator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.JAPANESE)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build()
        )

        var completed = 0
        fun oneReady() {
            completed++
            if (completed == 2 && running) startAudioCapture()
        }

        englishTranslator!!.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { oneReady() }
            .addOnFailureListener { showMessage("No se pudo descargar el traductor inglés: ${it.message}") }

        japaneseTranslator!!.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { oneReady() }
            .addOnFailureListener { showMessage("No se pudo descargar el traductor japonés: ${it.message}") }
    }

    private fun startAudioCapture() {
        if (!running) return
        try {
            val config = android.media.AudioPlaybackCaptureConfiguration.Builder(
                projection ?: throw IllegalStateException("No hay autorización de captura.")
            )
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()

            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()

            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) throw IllegalStateException("Formato de audio no compatible.")

            val recorder = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(maxOf(minBuffer * 2, 8192))
                .setAudioPlaybackCaptureConfig(config)
                .build()

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                throw IllegalStateException("Android no pudo iniciar la captura de audio.")
            }

            audioRecord = recorder
            recorder.startRecording()
            showMessage("Escuchando… abre TikTok y reproduce un LIVE.")
            thread(name = "audio-recognition") {
                val buffer = ByteArray(4096)
                while (running) {
                    val count = recorder.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        val enFinal = englishRecognizer?.acceptWaveForm(buffer, count) == true
                        val jaFinal = japaneseRecognizer?.acceptWaveForm(buffer, count) == true

                        if (enFinal) {
                            val text = JSONObject(englishRecognizer?.result ?: "{}").optString("text")
                            if (text.isNotBlank()) identifyAndTranslate(text, "en")
                        }
                        if (jaFinal) {
                            val text = JSONObject(japaneseRecognizer?.result ?: "{}").optString("text")
                            if (text.isNotBlank()) identifyAndTranslate(text, "ja")
                        }
                    } else if (count < 0) {
                        showMessage("Error leyendo el audio ($count).")
                        break
                    }
                }
            }
        } catch (e: Exception) {
            showMessage("No se puede capturar el audio: ${e.message}")
        }
    }

    private fun identifyAndTranslate(text: String, recognizerLanguage: String) {
        if (!running || text == lastText) return
        if (languageMode != "auto" && languageMode != recognizerLanguage) return

        if (languageMode != "auto") {
            lastText = text
            translate(text, recognizerLanguage)
            return
        }

        languageIdentifier.identifyPossibleLanguages(text)
            .addOnSuccessListener { languages ->
                if (!running) return@addOnSuccessListener
                val best = languages.maxByOrNull { it.confidence }
                val detected = best?.languageTag
                if (best != null && best.confidence >= 0.60f && detected in listOf("en", "ja")) {
                    lastText = text
                    translate(text, detected!!)
                }
            }
            .addOnFailureListener {
                // Si no se puede identificar con suficiente seguridad, se descarta el fragmento.
            }
    }

    private fun translate(text: String, language: String) {
        val translator = if (language == "ja") japaneseTranslator else englishTranslator
        translator?.translate(text)
            ?.addOnSuccessListener { translated ->
                if (translated.isNotBlank()) showMessage(translated)
            }
            ?.addOnFailureListener { error ->
                showMessage("Error de traducción: ${error.message}")
            }
    }

    private fun downloadAndExtractModel(modelName: String, url: String): File {
        val base = File(filesDir, "vosk")
        if (!base.exists()) base.mkdirs()
        val destination = File(base, modelName)
        val marker = File(destination, "am/final.mdl")
        if (marker.exists()) return destination

        if (destination.exists()) destination.deleteRecursively()
        destination.mkdirs()

        val zipFile = File(cacheDir, "$modelName.zip")
        URL(url).openStream().use { input ->
            zipFile.outputStream().use { output -> input.copyTo(output) }
        }

        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val relative = entry.name.substringAfter('/', "")
                if (relative.isNotEmpty()) {
                    val target = File(destination, relative)
                    if (!target.canonicalPath.startsWith(destination.canonicalPath + File.separator)) {
                        throw SecurityException("Archivo ZIP no válido.")
                    }
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { output -> zip.copyTo(output) }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        zipFile.delete()

        if (!marker.exists()) {
            destination.deleteRecursively()
            throw IllegalStateException("El modelo $modelName se descargó incompleto.")
        }
        return destination
    }

    private fun showOverlay() {
        val textView = TextView(this).apply {
            text = "Preparando subtítulos…"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            setBackgroundColor(0xCC111111.toInt())
            setPadding(28, 18, 28, 18)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            y = 180
        }

        try {
            getSystemService(WindowManager::class.java).addView(textView, params)
            overlay = textView
        } catch (e: Exception) {
            showMessage("No se pudo mostrar la ventana flotante: ${e.message}")
        }
    }

    private fun showMessage(message: String) {
        mainHandler.post {
            overlay?.text = message
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Subtítulos Live",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        audioRecord?.release()
        audioRecord = null

        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        projection = null

        overlay?.let {
            try {
                getSystemService(WindowManager::class.java).removeView(it)
            } catch (_: Exception) {
            }
        }
        overlay = null

        englishRecognizer?.close()
        japaneseRecognizer?.close()
        englishModel?.close()
        japaneseModel?.close()
        englishTranslator?.close()
        japaneseTranslator?.close()
        languageIdentifier.close()

        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val EXTRA_LANGUAGE_MODE = "language_mode"

        private const val CHANNEL_ID = "subtitles_live_channel"
        private const val NOTIFICATION_ID = 1001
        private const val SAMPLE_RATE = 16000
    }
}
